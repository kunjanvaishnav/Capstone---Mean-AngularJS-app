angular.module('mean', ['ngCookies', 'ngResource', 'ngRoute', 'ui.bootstrap', 'ui.route', 'UserChat.system', 'UserChat.User']);

angular.module('UserChat.system', []);
angular.module('UserChat.User', []);